// 获取 WebGL 上下文
const canvas = document.getElementById('glCanvas');
const gl = canvas.getContext('webgl');
if (!gl) {
    console.error("WebGL not supported");
    throw new Error("WebGL not supported");
}

// 顶点着色器
const vertexShaderSource = `
    attribute vec3 aPosition;
    attribute vec3 aNormal;

    uniform mat4 uModelMatrix;
    uniform mat4 uViewMatrix;
    uniform mat4 uProjectionMatrix;

    varying vec3 vNormal;
    varying vec3 vPosition;

    void main() {
        vec4 worldPosition = uModelMatrix * vec4(aPosition, 1.0);
        vPosition = worldPosition.xyz;
        vNormal = mat3(uModelMatrix) * aNormal; // 转换法线到世界坐标系
        gl_Position = uProjectionMatrix * uViewMatrix * worldPosition;
    }
`;

// 片元着色器
const fragmentShaderSource = `
    precision mediump float;

    varying vec3 vNormal;
    varying vec3 vPosition;

    uniform vec3 uLightPosition;
    uniform vec3 uLightColor;
    uniform vec3 uMaterialAmbient;
    uniform vec3 uMaterialDiffuse;
    uniform vec3 uMaterialSpecular;
    uniform float uShininess;

    void main() {
        vec3 normal = normalize(vNormal);
        vec3 lightDir = normalize(uLightPosition - vPosition);
        vec3 viewDir = normalize(-vPosition);
        vec3 reflectDir = reflect(-lightDir, normal);

        // 环境光
        vec3 ambient = uMaterialAmbient * uLightColor;

        // 漫反射
        float diff = max(dot(normal, lightDir), 0.0);
        vec3 diffuse = diff * uMaterialDiffuse * uLightColor;

        // 高光
        float spec = pow(max(dot(viewDir, reflectDir), 0.0), uShininess);
        vec3 specular = spec * uMaterialSpecular * uLightColor;

        gl_FragColor = vec4(ambient + diffuse + specular, 1.0);
    }
`;

// 初始化着色器程序
function createShader(gl, type, source) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        console.error(`Shader compile failed: ${gl.getShaderInfoLog(shader)}`);
        gl.deleteShader(shader);
        return null;
    }
    return shader;
}

function createProgram(gl, vertexShader, fragmentShader) {
    const program = gl.createProgram();
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
        console.error(`Program link failed: ${gl.getProgramInfoLog(program)}`);
        gl.deleteProgram(program);
        return null;
    }
    return program;
}

// 生成球体顶点数据
function generateSphere(radius, subdivisions) {
    const vertices = [];
    const normals = [];
    const indices = [];
    const phiStep = Math.PI / subdivisions;
    const thetaStep = 2 * Math.PI / subdivisions;

    for (let i = 0; i <= subdivisions; i++) {
        const phi = i * phiStep;
        for (let j = 0; j <= subdivisions; j++) {
            const theta = j * thetaStep;
            const x = radius * Math.sin(phi) * Math.cos(theta);
            const y = radius * Math.sin(phi) * Math.sin(theta);
            const z = radius * Math.cos(phi);

            vertices.push(x, y, z);
            normals.push(x, y, z); // 法线方向与顶点一致（球心指向顶点）
        }
    }

    for (let i = 0; i < subdivisions; i++) {
        for (let j = 0; j < subdivisions; j++) {
            const first = i * (subdivisions + 1) + j;
            const second = first + subdivisions + 1;

            indices.push(first, second, first + 1);
            indices.push(second, second + 1, first + 1);
        }
    }

    return {
        vertices: new Float32Array(vertices),
        normals: new Float32Array(normals),
        indices: new Uint16Array(indices),
    };
}

// 初始化 WebGL 程序
const vertexShader = createShader(gl, gl.VERTEX_SHADER, vertexShaderSource);
const fragmentShader = createShader(gl, gl.FRAGMENT_SHADER, fragmentShaderSource);
const program = createProgram(gl, vertexShader, fragmentShader);
gl.useProgram(program);

// 生成球体数据
const sphereData = generateSphere(1.0, 24);

// 创建顶点缓冲区
const positionBuffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
gl.bufferData(gl.ARRAY_BUFFER, sphereData.vertices, gl.STATIC_DRAW);

// 创建法线缓冲区
const normalBuffer = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, normalBuffer);
gl.bufferData(gl.ARRAY_BUFFER, sphereData.normals, gl.STATIC_DRAW);

// 创建索引缓冲区
const indexBuffer = gl.createBuffer();
gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);
gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, sphereData.indices, gl.STATIC_DRAW);

// 获取 attribute 和 uniform 位置
const aPosition = gl.getAttribLocation(program, 'aPosition');
const aNormal = gl.getAttribLocation(program, 'aNormal');
const uModelMatrix = gl.getUniformLocation(program, 'uModelMatrix');
const uViewMatrix = gl.getUniformLocation(program, 'uViewMatrix');
const uProjectionMatrix = gl.getUniformLocation(program, 'uProjectionMatrix');
const uLightPosition = gl.getUniformLocation(program, 'uLightPosition');
const uLightColor = gl.getUniformLocation(program, 'uLightColor');
const uMaterialAmbient = gl.getUniformLocation(program, 'uMaterialAmbient');
const uMaterialDiffuse = gl.getUniformLocation(program, 'uMaterialDiffuse');
const uMaterialSpecular = gl.getUniformLocation(program, 'uMaterialSpecular');
const uShininess = gl.getUniformLocation(program, 'uShininess');

// 绑定顶点缓冲区
gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
gl.vertexAttribPointer(aPosition, 3, gl.FLOAT, false, 0, 0);
gl.enableVertexAttribArray(aPosition);

// 绑定法线缓冲区
gl.bindBuffer(gl.ARRAY_BUFFER, normalBuffer);
gl.vertexAttribPointer(aNormal, 3, gl.FLOAT, false, 0, 0);
gl.enableVertexAttribArray(aNormal);

// 设置灯光和材质初始值
gl.uniform3fv(uLightPosition, [2.0, 2.0, 2.0]);
gl.uniform3fv(uLightColor, [1.0, 1.0, 1.0]);
gl.uniform3fv(uMaterialAmbient, [0.2, 0.2, 0.2]);
gl.uniform3fv(uMaterialDiffuse, [0.5, 0.5, 0.5]);
gl.uniform3fv(uMaterialSpecular, [1.0, 1.0, 1.0]);
gl.uniform1f(uShininess, 32.0);

// 设置模型、视图和投影矩阵
const modelMatrix = mat4.create();
const viewMatrix = mat4.lookAt([], [0, 0, 5], [0, 0, 0], [0, 1, 0]);
const projectionMatrix = mat4.perspective([], Math.PI / 4, canvas.width / canvas.height, 0.1, 100.0);

gl.uniformMatrix4fv(uModelMatrix, false, modelMatrix);
gl.uniformMatrix4fv(uViewMatrix, false, viewMatrix);
gl.uniformMatrix4fv(uProjectionMatrix, false, projectionMatrix);

// 启用深度测试
gl.enable(gl.DEPTH_TEST);

// 渲染循环
function render() {
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.drawElements(gl.TRIANGLES, sphereData.indices.length, gl.UNSIGNED_SHORT, 0);
    requestAnimationFrame(render);
}

// 开始渲染
render();
