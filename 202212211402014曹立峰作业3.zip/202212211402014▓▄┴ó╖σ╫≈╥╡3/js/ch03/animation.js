// 获取WebGL上下文
var canvas;
var gl;
const { mat4 } = glMatrix;

// 初始化变量
let angleX = 0; // X轴旋转角度
let angleY = 0; // Y轴旋转角度
let lastMouseX = 0; // 上次鼠标X坐标
let lastMouseY = 0; // 上次鼠标Y坐标
let isDragging = false; // 是否正在拖动

// 初始化
function init() {
    canvas = document.getElementById('glCanvas');
    gl = canvas.getContext('webgl');
    if (!gl) {
        alert('无法获取WebGL上下文');
        return;
    }

    // 设置视口
    gl.viewport(0, 0, canvas.width, canvas.height);

    // 清除颜色
    gl.clearColor(0.0, 0.0, 0.0, 1.0);

    // 初始化着色器程序
    const vertexShaderSource = `
    attribute vec4 a_Position;
    uniform mat4 u_ModelViewMatrix;
    uniform mat4 u_ProjectionMatrix;
    void main() {
        gl_Position = u_ProjectionMatrix * u_ModelViewMatrix * a_Position;
    }`;

    const fragmentShaderSource = `
    precision mediump float;
    uniform vec4 u_FragColor;
    void main() {
        gl_FragColor = u_FragColor;
    }`;

    function createShader(gl, type, source) {
        const shader = gl.createShader(type);
        gl.shaderSource(shader, source);
        gl.compileShader(shader);
        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
            console.error(`An error occurred compiling the shaders: ${gl.getShaderInfoLog(shader)}`);
            gl.deleteShader(shader);
            return null;
        }
        return shader;
    }

    function createProgram(gl, vertexShader, fragmentShader) {
        const program = gl.createProgram();
        gl.attachShader(program, vertexShader);
        gl.attachShader(program, fragmentShader);
        gl.linkProgram(program);
        if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
            console.error(`Unable to initialize the shader program: ${gl.getProgramInfoLog(program)}`);
            return null;
        }
        return program;
    }

    const vertexShader = createShader(gl, gl.VERTEX_SHADER, vertexShaderSource);
    const fragmentShader = createShader(gl, gl.FRAGMENT_SHADER, fragmentShaderSource);
    const program = createProgram(gl, vertexShader, fragmentShader);

    if (!program) {
        alert('无法初始化着色器程序');
        return;
    }

    // 使用着色器程序
    gl.useProgram(program);

    // 获取uniform变量位置
    const u_ModelViewMatrix = gl.getUniformLocation(program, 'u_ModelViewMatrix');
    const u_ProjectionMatrix = gl.getUniformLocation(program, 'u_ProjectionMatrix');
    const u_FragColor = gl.getUniformLocation(program, 'u_FragColor');

    // 设置投影矩阵
    const projectionMatrix = mat4.create(); // 引用 mat4 模块
    mat4.perspective(projectionMatrix, 45, canvas.width / canvas.height, 0.1, 100.0);
    gl.uniformMatrix4fv(u_ProjectionMatrix, false, projectionMatrix);

    // 函数：绘制立方体
    function drawCube(modelViewMatrix, color) {
        // 立方体顶点数据
    const vertices = [
        -1.0, -1.0,  1.0,
         1.0, -1.0,  1.0,
         1.0,  1.0,  1.0,
        -1.0,  1.0,  1.0,
        -1.0, -1.0, -1.0,
         1.0, -1.0, -1.0,
         1.0,  1.0, -1.0,
        -1.0,  1.0, -1.0
    ];

    // 索引数据
    const indices = [
        0, 1, 2, 0, 2, 3,    // 前面
        4, 5, 6, 4, 6, 7,    // 后面
        0, 4, 7, 0, 7, 3,    // 左面
        1, 5, 6, 1, 6, 2,    // 右面
        0, 1, 5, 0, 5, 4,    // 下面
        2, 6, 7, 2, 7, 3     // 上面
    ];

    // 创建并绑定缓冲区对象
    const vertexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);

    const indexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(indices), gl.STATIC_DRAW);

    // 设置顶点属性指针
    const a_Position = gl.getAttribLocation(program, 'a_Position');
    gl.vertexAttribPointer(a_Position, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(a_Position);

    // 设置颜色
    gl.uniform4fv(u_FragColor, color);

    // 设置模型视图矩阵
    gl.uniformMatrix4fv(u_ModelViewMatrix, false, modelViewMatrix);

    // 绘制立方体
    gl.drawElements(gl.TRIANGLES, indices.length, gl.UNSIGNED_SHORT, 0);
    }

    // 函数：绘制粒子
    function drawParticles(particles, modelViewMatrix, color) {
        // 创建并绑定缓冲区对象
    const vertexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(particles), gl.DYNAMIC_DRAW);

    // 设置顶点属性指针
    const a_Position = gl.getAttribLocation(program, 'a_Position');
    gl.vertexAttribPointer(a_Position, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(a_Position);

    // 设置颜色
    gl.uniform4fv(u_FragColor, color);

    // 设置模型视图矩阵
    gl.uniformMatrix4fv(u_ModelViewMatrix, false, modelViewMatrix);

    // 绘制粒子
    gl.drawArrays(gl.POINTS, 0, particles.length / 3);
    }

    // 动画循环
    let angle = 0;
    function animate() {
        requestAnimationFrame(animate);

        // 清除颜色和深度缓存
        gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

        // 设置相机矩阵
        const viewMatrix = mat4.create();
        mat4.lookAt(viewMatrix, [0, 0, 5], [0, 0, 0], [0, 1, 0]);

        // 绘制旋转的立方体
        const modelMatrix = mat4.create();
        mat4.rotateY(modelMatrix, modelMatrix, angleY); // 旋转Y轴
        mat4.rotateX(modelMatrix, modelMatrix, angleX); // 旋转X轴
        drawCube(mat4.multiply(mat4.create(), viewMatrix, modelMatrix), [0.0, 1.0, 0.0, 1.0]);

        // 绘制粒子
        const numParticles = 100;
        const particles = [];
        for (let i = 0; i < numParticles; i++) {
            particles.push(
                Math.random() * 10 - 5,
                Math.random() * 10 - 5,
                Math.random() * 10 - 5
            );
        }
        drawParticles(particles, viewMatrix, [1.0, 0.0, 0.0, 1.0]);

        // 更新角度
        angle += 0.01;
    }

    // 键盘事件处理
    window.addEventListener('keydown', (event) => {
        switch (event.key) {
            case 'ArrowUp':
                angleX -= 0.1;
                break;
            case 'ArrowDown':
                angleX += 0.1;
                break;
            case 'ArrowLeft':
                angleY += 0.1;
                break;
            case 'ArrowRight':
                angleY -= 0.1;
                break;
        }
    });

    // 鼠标事件处理
    canvas.addEventListener('mousedown', (event) => {
        isDragging = true;
        lastMouseX = event.clientX;
        lastMouseY = event.clientY;
    });

    canvas.addEventListener('mouseup', () => {
        isDragging = false;
    });

    canvas.addEventListener('mousemove', (event) => {
        if (isDragging) {
            const deltaX = event.clientX - lastMouseX;
            const deltaY = event.clientY - lastMouseY;

            angleY += deltaX * 0.01; // 旋转Y轴
            angleX += deltaY * 0.01; // 旋转X轴

            lastMouseX = event.clientX;
            lastMouseY = event.clientY;
        }
    });

    // 开始动画
    animate();
}

// 调用初始化函数
init();