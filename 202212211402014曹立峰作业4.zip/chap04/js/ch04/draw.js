const canvas = document.getElementById('webglCanvas');
const gl = canvas.getContext('webgl');

let selectedShape = 'cube';
let angleX = 0, angleY = 0;
let posX = 0, posY = 0;
let triangleScale = 1, triangleDirection = 1;
let squareRotation = 0;
let circleSides = 20;
let isAnimating = true;

// 变量声明
let cubeVertexBuffer;
let indexBuffer;

// 立方体顶点和索引
const cubeVertices = new Float32Array([
    -1, -1, -1,   1, -1, -1,   1,  1, -1,   -1,  1, -1,
    -1, -1,  1,   1, -1,  1,   1,  1,  1,   -1,  1,  1,
]);

const cubeIndices = new Uint16Array([
    0, 1, 2, 0, 2, 3,
    4, 5, 6, 4, 6, 7,
    0, 1, 5, 0, 5, 4,
    2, 3, 7, 2, 7, 6,
    3, 0, 4, 3, 4, 7,
    1, 2, 6, 1, 6, 5
]);

// 初始化
initShaders();
initCubeBuffers();

gl.enable(gl.DEPTH_TEST);

function initShaders() {
    const vertexShaderSource = `
        attribute vec4 a_Position;
        uniform mat4 u_ModelMatrix;
        void main() {
            gl_Position = u_ModelMatrix * a_Position;
        }
    `;

    const fragmentShaderSource = `
        precision mediump float;
        void main() {
            gl_FragColor = vec4(0.0, 0.5, 0.5, 1.0);
        }
    `;

    const vertexShader = createShader(gl.VERTEX_SHADER, vertexShaderSource);
    const fragmentShader = createShader(gl.FRAGMENT_SHADER, fragmentShaderSource);
    const program = gl.createProgram();
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);
    gl.useProgram(program);
    gl.program = program;
}

function createShader(type, source) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        return shader;
    } else {
        console.error(gl.getShaderInfoLog(shader));
        gl.deleteShader(shader);
    }
}

function initCubeBuffers() {
    cubeVertexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, cubeVertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, cubeVertices, gl.STATIC_DRAW);

    const a_Position = gl.getAttribLocation(gl.program, 'a_Position');
    gl.vertexAttribPointer(a_Position, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(a_Position);

    indexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, cubeIndices, gl.STATIC_DRAW);
}

function drawCube() {
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    const u_ModelMatrix = gl.getUniformLocation(gl.program, 'u_ModelMatrix');
    const modelMatrix = mat4.create();
    mat4.translate(modelMatrix, modelMatrix, [posX, posY, -10]);

    angleY += 0.01; // 自转
    mat4.rotateY(modelMatrix, modelMatrix, angleY);
    gl.uniformMatrix4fv(u_ModelMatrix, false, modelMatrix);

    gl.drawElements(gl.TRIANGLES, cubeIndices.length, gl.UNSIGNED_SHORT, 0);
}

function drawTriangle() {
    const u_ModelMatrix = gl.getUniformLocation(gl.program, 'u_ModelMatrix');
    const modelMatrix = mat4.create();
    mat4.translate(modelMatrix, modelMatrix, [posX, posY, -5]);
    mat4.scale(modelMatrix, modelMatrix, [triangleScale, triangleScale, 1]);
    gl.uniformMatrix4fv(u_ModelMatrix, false, modelMatrix);

    const triangleVertices = new Float32Array([
        0, 1, 0,
        -1, -1, 0,
        1, -1, 0
    ]);

    const triangleBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, triangleBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, triangleVertices, gl.STATIC_DRAW);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
}

function drawSquare() {
    const u_ModelMatrix = gl.getUniformLocation(gl.program, 'u_ModelMatrix');
    const modelMatrix = mat4.create();
    mat4.translate(modelMatrix, modelMatrix, [posX, posY, -5]);
    gl.uniformMatrix4fv(u_ModelMatrix, false, modelMatrix);

    const squareVertices = new Float32Array([
        -1, -1, 0,
        1, -1, 0,
        1, 1, 0,
        -1, 1, 0,
    ]);

    const squareBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, squareBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, squareVertices, gl.STATIC_DRAW);
    gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);
}

function drawCircle() {
    const vertices = [];
    for (let i = 0; i < circleSides; i++) {
        const angle = (i / circleSides) * Math.PI * 2;
        vertices.push(Math.cos(angle), Math.sin(angle), 0);
    }
    const circleBuffer = new Float32Array(vertices);

    const u_ModelMatrix = gl.getUniformLocation(gl.program, 'u_ModelMatrix');
    const modelMatrix = mat4.create();
    mat4.translate(modelMatrix, modelMatrix, [posX, posY, -5]);
    gl.uniformMatrix4fv(u_ModelMatrix, false, modelMatrix);

    const circleVertexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, circleVertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, circleBuffer, gl.STATIC_DRAW);
    gl.drawArrays(gl.TRIANGLE_FAN, 0, circleSides);
}

function drawShapes() {
    switch (selectedShape) {
        case 'cube':
            drawCube();
            break;
        case 'triangle':
            drawTriangle();
            break;
        case 'square':
            drawSquare();
            break;
        case 'circle':
            drawCircle();
            break;
    }
}

function selectShape(type) {
    selectedShape = type;
}

function updateCircleSides() {
    circleSides = document.getElementById('sides').value;
}

function clearScene() {
    gl.clearColor(0.8, 0.8, 0.8, 1.0);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
}

canvas.addEventListener('click', (event) => {
    const rect = canvas.getBoundingClientRect();
    posX = ((event.clientX - rect.left) / canvas.width) * 2 - 1;
    posY = -(((event.clientY - rect.top) / canvas.height) * 2 - 1); // Y轴反转
});

function animate() {
    if (isAnimating) {
        drawShapes();
    }
    requestAnimationFrame(animate);
}

animate();
