 "use strict";

const { vec3 } = glMatrix;

var gl;
var canvas;

var points = [];
var colors = [];
var vertexBuffer;
var colorBuffer;
var program
var t, u, v, w; // 四面体顶点

function getnum() {
    return parseInt(document.getElementById("cen").value, 10);
}

function init() {
    canvas = document.getElementById("gl-canvas");

    gl = canvas.getContext("webgl2");
    if (!gl) {
        alert("WebGL isn't available");
        return;
    }

    // 初始化 3D Sierpinski 四面体的数据
    var vertices = [
        0.0000, 0.0000, -1.0000,
        0.0000, 0.9428, 0.3333,
        -0.8165, -0.4714, 0.3333,
        0.8165, -0.4714, 0.3333
    ];

    t = vec3.fromValues(vertices[0], vertices[1], vertices[2]);
    u = vec3.fromValues(vertices[3], vertices[4], vertices[5]);
    v = vec3.fromValues(vertices[6], vertices[7], vertices[8]);
    w = vec3.fromValues(vertices[9], vertices[10], vertices[11]);

    // 配置 WebGL
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(1.0, 1.0, 1.0, 1.0);

    // 启用深度测试
    gl.enable(gl.DEPTH_TEST);

    // 加载着色器并初始化属性缓冲
    program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);

    // 创建缓冲区对象
    vertexBuffer = gl.createBuffer();
    colorBuffer = gl.createBuffer();

    // 关联着色器变量与数据缓冲
    var vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    var aColor = gl.getAttribLocation(program, "aColor");
    gl.vertexAttribPointer(aColor, 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(aColor);

    // 初始绘制
    updateAndRender();
}

function triangle(a, b, c, color) {
    // 添加颜色和顶点
    var baseColor = [
        1.0, 0.0, 0.0, 1.0,
        0.0, 1.0, 0.0, 1.0,
        0.0, 0.0, 1.0, 1.0,
        0.0, 0.0, 0.0, 1.0
    ];

    for (var k = 0; k < 4; k++) {
        colors.push(baseColor[color * 4 + k]);
    }
    for (var k = 0; k < 3; k++)
        points.push(a[k]);

    for (var k = 0; k < 4; k++) {
        colors.push(baseColor[color * 4 + k]);
    }
    for (var k = 0; k < 3; k++)
        points.push(b[k]);

    for (var k = 0; k < 4; k++) {
        colors.push(baseColor[color * 4 + k]);
    }
    for (var k = 0; k < 3; k++)
        points.push(c[k]);
}

function tetra(a, b, c, d) {
    triangle(a, c, b, 0);
    triangle(a, c, d, 1);
    triangle(a, b, d, 2);
    triangle(b, c, d, 3);
}

function divideTetra(a, b, c, d, count) {
    if (count == 0) {
        tetra(a, b, c, d);
    } else {
        var ab = vec3.create();
        vec3.lerp(ab, a, b, 0.5);
        var ac = vec3.create();
        vec3.lerp(ac, a, c, 0.5);
        var ad = vec3.create();
        vec3.lerp(ad, a, d, 0.5);
        var bc = vec3.create();
        vec3.lerp(bc, b, c, 0.5);
        var bd = vec3.create();
        vec3.lerp(bd, b, d, 0.5);
        var cd = vec3.create();
        vec3.lerp(cd, c, d, 0.5);

        --count;

        divideTetra(a, ab, ac, ad, count);
        divideTetra(ab, b, bc, bd, count);
        divideTetra(ac, bc, c, cd, count);
        divideTetra(ad, bd, cd, d, count);
    }
}

function render() {
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    // 绑定顶点缓冲区
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    var vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    // 绑定颜色缓冲区
    gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer);
    var aColor = gl.getAttribLocation(program, "aColor");
    gl.vertexAttribPointer(aColor, 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(aColor);

    gl.drawArrays(gl.TRIANGLES, 0, points.length / 3);
}

function updateAndRender() {
    points = []; // 清空旧的数据
    colors = []; // 清空旧的颜色

    var numTimesToSubdivide = getnum();
    console.log("Number of subdivisions: " + numTimesToSubdivide); // 调试信息
    if (isNaN(numTimesToSubdivide)) {
        console.error("Invalid input. Please enter a valid number.");
        return;
    }

    divideTetra(t, u, v, w, numTimesToSubdivide);

    // 更新顶点缓冲区数据
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(points), gl.STATIC_DRAW);

    // 更新颜色缓冲区数据
    gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(colors), gl.STATIC_DRAW);

    // 重新渲染
    render();
}

// 添加事件监听器来响应细分次数的变化
window.onload = init;
